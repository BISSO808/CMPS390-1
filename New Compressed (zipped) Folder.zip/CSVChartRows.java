package cmps390;

import java.util.Scanner;

public class CSVChartRows {

  public static void main(String[] args) throws Exception {
Scanner input=new Scanner(System.in);
int element=input.nextInt();
	  double radian  = Math.sin( Math.toRadians( element ) ) ;
		System.out.println(radian);
  }
}


